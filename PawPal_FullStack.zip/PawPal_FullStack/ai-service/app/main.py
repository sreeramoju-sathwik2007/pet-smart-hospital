from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import Any

app = FastAPI(title='PawPal AI Service', version='1.0.0')

class InsightRequest(BaseModel):
    pet: dict[str, Any] = Field(default_factory=dict)
    signals: dict[str, Any] = Field(default_factory=dict)

@app.get('/health')
def health():
    return {'service':'pawpal-ai-service','status':'online'}

@app.post('/v1/insights')
def insights(payload: InsightRequest):
    pet = payload.pet
    species = pet.get('species', 'pet')
    age = pet.get('age_years', 0)
    score = 86
    if isinstance(age, (int, float)) and age >= 8:
        score = 80
    return {
        'pet_id': pet.get('id'),
        'wellness_score': score,
        'trend': 'Healthy trend',
        'summary': f'General wellness guidance generated for this {species.lower()}.',
        'recommendations': [
            'Keep preventive-care reminders up to date.',
            'Maintain species-appropriate nutrition and activity.',
            'Use a qualified veterinarian for diagnosis or treatment decisions.'
        ],
        'safety_note': 'This is general AI assistance and does not replace veterinary diagnosis or treatment.'
    }
