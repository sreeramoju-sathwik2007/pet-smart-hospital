import dotenv from 'dotenv';
dotenv.config();
const AI_URL = process.env.AI_SERVICE_URL || 'http://localhost:8000';
export async function getWellnessInsight(payload) {
  const response = await fetch(`${AI_URL}/v1/insights`, {
    method: 'POST', headers: {'content-type':'application/json'}, body: JSON.stringify(payload)
  });
  if (!response.ok) throw new Error(`AI service returned ${response.status}`);
  return response.json();
}
