import { Router } from 'express';
import { z } from 'zod';
import { query } from '../db.js';
const router=Router();
const schema=z.object({pet_id:z.number().int(), vet_id:z.number().int().optional(), service_id:z.number().int().optional(), scheduled_at:z.string(), notes:z.string().optional()});
router.get('/', async (req,res,next)=>{try{const r=await query(`SELECT a.*,p.name AS pet_name,v.name AS vet_name,s.name AS service_name FROM appointments a JOIN pets p ON p.id=a.pet_id LEFT JOIN vets v ON v.id=a.vet_id LEFT JOIN care_services s ON s.id=a.service_id ORDER BY scheduled_at DESC`);res.json(r.rows)}catch(e){next(e)}});
router.post('/', async (req,res,next)=>{try{const d=schema.parse(req.body);const r=await query('INSERT INTO appointments(pet_id,vet_id,service_id,scheduled_at,notes) VALUES($1,$2,$3,$4,$5) RETURNING *',[d.pet_id,d.vet_id||null,d.service_id||null,d.scheduled_at,d.notes||null]);res.status(201).json(r.rows[0])}catch(e){next(e)}});
export default router;
