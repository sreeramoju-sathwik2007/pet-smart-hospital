import { Router } from 'express';
import { query } from '../db.js';
const router = Router();
router.get('/', async (req,res,next)=>{ try { const r=await query('SELECT * FROM care_services ORDER BY price_inr'); res.json(r.rows); } catch(e){next(e)} });
export default router;
