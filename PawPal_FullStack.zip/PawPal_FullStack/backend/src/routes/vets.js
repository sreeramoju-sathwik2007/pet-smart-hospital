import { Router } from 'express';
import { query } from '../db.js';
const router = Router();
router.get('/', async (req,res,next)=>{ try { const q=String(req.query.q||''); const spec=String(req.query.specialization||''); const r=await query(`SELECT * FROM vets WHERE ($1='' OR name ILIKE '%'||$1||'%' OR specialization ILIKE '%'||$1||'%' OR qualification ILIKE '%'||$1||'%') AND ($2='' OR specialization ILIKE '%'||$2||'%') ORDER BY rating DESC`,[q,spec]); res.json(r.rows); } catch(e){next(e)} });
export default router;
