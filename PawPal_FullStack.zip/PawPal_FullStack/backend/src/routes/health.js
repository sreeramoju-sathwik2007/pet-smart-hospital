import { Router } from 'express';
import { query } from '../db.js';
const router = Router();
router.get('/', async (req,res) => {
  let database = 'offline';
  try { await query('SELECT 1'); database = 'online'; } catch (_) {}
  res.json({ service:'pawpal-backend', status:'online', database, timestamp:new Date().toISOString() });
});
export default router;
