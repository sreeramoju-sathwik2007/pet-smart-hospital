# PawPal REST API examples

## List vets

`GET http://localhost:4000/api/vets?specialization=Exotics`

## Create a pet

```json
POST /api/pets
{
  "owner_name": "Demo User",
  "name": "Buddy",
  "species": "Dog",
  "breed": "Indie",
  "age_years": 3
}
```

## Create an appointment

```json
POST /api/appointments
{
  "pet_id": 1,
  "vet_id": 1,
  "service_id": 2,
  "scheduled_at": "2026-10-15T10:30:00+05:30",
  "notes": "Routine wellness review"
}
```

## AI wellness insight

```json
POST http://localhost:8000/v1/insights
{
  "pet": {"id": 1, "name": "Max", "species": "Dog", "age_years": 3},
  "signals": {"activity": "normal"}
}
```
