# PawPal Architecture

```text
┌──────────────────────────┐
│ Frontend                 │
│ HTML + CSS + JavaScript  │
│ Future-gen dashboard     │
└────────────┬─────────────┘
             │ REST / JSON
             ▼
┌──────────────────────────┐
│ Backend                  │
│ Node.js + Express        │
│ Validation + business    │
│ logic + persistence      │
└───────┬───────────┬──────┘
        │ SQL       │ HTTP
        ▼           ▼
┌──────────────┐ ┌───────────────────┐
│ PostgreSQL   │ │ AI Service        │
│ pets         │ │ Python + FastAPI  │
│ vets         │ │ wellness insights │
│ services     │ │ recommendations   │
│ appointments │ └───────────────────┘
└──────────────┘
```

## REST endpoints

- `GET /api/health`
- `GET /api/pets`
- `POST /api/pets`
- `GET /api/pets/:id/wellness`
- `GET /api/vets?q=&specialization=`
- `GET /api/services`
- `GET /api/appointments`
- `POST /api/appointments`
- `GET /health` on the AI service
- `POST /v1/insights` on the AI service

## Production expansion

Add authentication/JWT, role-based access, encrypted document storage, audit logging, rate limiting, background reminders, real payment integration, real clinic/provider verification, observability and a production-grade AI gateway before deployment.
