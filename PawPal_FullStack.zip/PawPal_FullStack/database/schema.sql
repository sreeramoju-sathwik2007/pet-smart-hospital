CREATE TABLE IF NOT EXISTS pets (
  id SERIAL PRIMARY KEY,
  owner_name VARCHAR(120) NOT NULL,
  name VARCHAR(80) NOT NULL,
  species VARCHAR(50) NOT NULL,
  breed VARCHAR(100),
  age_years NUMERIC(4,1) DEFAULT 0,
  allergies TEXT,
  care_preferences TEXT,
  microchip_id VARCHAR(100),
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS vets (
  id SERIAL PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  qualification VARCHAR(160) NOT NULL,
  specialization VARCHAR(160) NOT NULL,
  experience_years INT DEFAULT 0,
  languages VARCHAR(200),
  consultation_fee_inr NUMERIC(10,2) NOT NULL,
  rating NUMERIC(2,1) DEFAULT 0,
  fictional_sample BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS care_services (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  category VARCHAR(80) NOT NULL,
  description TEXT,
  price_inr NUMERIC(10,2) NOT NULL,
  billing_unit VARCHAR(50) NOT NULL,
  species_supported VARCHAR(300) DEFAULT 'Dogs,Cats'
);
CREATE TABLE IF NOT EXISTS appointments (
  id SERIAL PRIMARY KEY,
  pet_id INT NOT NULL REFERENCES pets(id) ON DELETE CASCADE,
  vet_id INT REFERENCES vets(id) ON DELETE SET NULL,
  service_id INT REFERENCES care_services(id) ON DELETE SET NULL,
  scheduled_at TIMESTAMPTZ NOT NULL,
  status VARCHAR(30) DEFAULT 'scheduled',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS medications (
  id SERIAL PRIMARY KEY,
  pet_id INT NOT NULL REFERENCES pets(id) ON DELETE CASCADE,
  medicine_name VARCHAR(120) NOT NULL,
  dosage VARCHAR(120),
  schedule VARCHAR(120),
  start_date DATE,
  end_date DATE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS documents (
  id SERIAL PRIMARY KEY,
  pet_id INT NOT NULL REFERENCES pets(id) ON DELETE CASCADE,
  title VARCHAR(160) NOT NULL,
  document_type VARCHAR(80),
  storage_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
