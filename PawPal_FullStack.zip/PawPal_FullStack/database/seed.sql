INSERT INTO pets(owner_name,name,species,breed,age_years,allergies,care_preferences) VALUES
('Demo User','Max','Dog','Golden Retriever',3,'None recorded','Daily walks; grooming every 6 weeks'),
('Demo User','Luna','Cat','Persian',2,'Dust sensitivity','Indoor; coat care'),
('Demo User','Rio','Bird','Parrot',4,'None recorded','Enrichment and exotic specialist'),
('Demo User','Snowy','Rabbit','Mini Lop',1,'None recorded','Hay-first nutrition'),
('Demo User','Milo','Hamster','Syrian Hamster',1,'None recorded','Quiet handling'),
('Demo User','Coco','Turtle','Red-Eared Slider',5,'None recorded','Aquatic habitat checks'),
('Demo User','Kiwi','Dog','Indie',4,'None recorded','Training support'),
('Demo User','Nala','Cat','Indian Shorthair',3,'None recorded','Dental wellness')
ON CONFLICT DO NOTHING;
INSERT INTO vets(name,qualification,specialization,experience_years,languages,consultation_fee_inr,rating) VALUES
('Dr. Priya Sharma','DVM, MVSc','General + Surgery',12,'English, Telugu',600,4.9),
('Dr. Arjun Mehta','BVSc, MVSc','Internal Medicine',8,'English, Hindi',550,4.8),
('Dr. Sneha Reddy','DVM, MVSc','Preventive Care',10,'English, Telugu',650,4.9),
('Dr. Karthik Nair','BVSc, MVSc','Birds + Exotics',6,'English, Malayalam',500,4.7),
('Dr. Aisha Khan','DVM','Dermatology + Skin Care',9,'English, Hindi',700,4.8),
('Dr. Rahul Rao','BVSc, MVSc','Nutrition + Wellness',7,'English, Telugu',450,4.8)
ON CONFLICT DO NOTHING;
INSERT INTO care_services(name,category,description,price_inr,billing_unit,species_supported) VALUES
('Basic Care','Routine','General wellness review and preventive guidance',400,'per visit','Dogs,Cats,Rabbits,Birds'),
('Deep Care','Comprehensive','Extended health review and coordinated care plan',1800,'per session','Dogs,Cats,Rabbits,Birds,Exotics'),
('Grooming','Hygiene','Bath, coat care, nail and hygiene support',900,'per session','Dogs,Cats,Rabbits'),
('Training','Behavior','Positive-reinforcement training plan',700,'per session','Dogs,Cats,Birds'),
('Dental Wellness','Dental','Dental health review and hygiene support',650,'per session','Dogs,Cats,Rabbits'),
('Nutrition','Nutrition','Nutrition consultation and care planning',800,'per consult','All supported species'),
('Day Boarding','Boarding','Supervised daytime care',750,'per day','Dogs,Cats,Rabbits'),
('Bird & Exotic Care','Specialist','Species-specific specialist pathway',500,'from / consult','Birds,Reptiles,Rabbits,Small Pets')
ON CONFLICT DO NOTHING;
