// PawPal REST client. The UI can continue using demo data when the backend is unavailable.
window.PawPalAPI = (() => {
  const API_BASE = window.PAWPAL_API_BASE || 'http://localhost:4000/api';
  async function request(path, options = {}) {
    const res = await fetch(`${API_BASE}${path}`, {
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
      ...options
    });
    if (!res.ok) throw new Error(`API ${res.status}: ${await res.text()}`);
    return res.status === 204 ? null : res.json();
  }
  return {
    base: API_BASE,
    health: () => request('/health'),
    pets: () => request('/pets'),
    vets: (params = '') => request(`/vets${params ? `?${params}` : ''}`),
    services: () => request('/services'),
    appointments: () => request('/appointments'),
    createAppointment: payload => request('/appointments', { method: 'POST', body: JSON.stringify(payload) }),
    petWellness: petId => request(`/pets/${petId}/wellness`),
    aiInsight: payload => fetch('http://localhost:8000/v1/insights', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
    }).then(r => r.json())
  };
})();

// Non-blocking connection indicator. Demo UI remains functional if services are offline.
window.addEventListener('load', async () => {
  try {
    await window.PawPalAPI.health();
    const badge = document.createElement('div');
    badge.textContent = '● REST API connected';
    badge.style.cssText = 'position:fixed;right:18px;bottom:18px;padding:9px 13px;border:1px solid rgba(100,220,180,.35);background:rgba(10,35,30,.92);color:#8ff0c6;border-radius:999px;font:600 12px system-ui;z-index:9999;box-shadow:0 8px 30px rgba(0,0,0,.35)';
    document.body.appendChild(badge);
  } catch (_) {
    // Intentionally silent: static prototype mode remains available.
  }
});
