// Optional: before loading js/api.js, set a different API host.
// window.PAWPAL_API_BASE = 'https://api.example.com/api';
