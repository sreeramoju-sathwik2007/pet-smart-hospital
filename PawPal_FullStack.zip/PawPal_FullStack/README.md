# PawPal — Full-Stack Future-Gen Pet Care Platform

This package separates the PawPal prototype into the requested layers:

```text
Frontend (HTML/CSS/JS)
        ↓ REST/JSON
Backend (Node.js + Express)
        ↓ SQL
Database (PostgreSQL)
        ↘ HTTP
      AI Service (Python + FastAPI)
```

## Folders

- `frontend/` — futuristic PawPal dashboard UI and API client
- `backend/` — REST API, business logic, validation and AI-service integration
- `database/` — PostgreSQL schema and sample seed data
- `ai-service/` — separate Python/FastAPI service for AI-assisted pet-care insights
- `docs/` — architecture and API documentation
- `docker-compose.yml` — optional local PostgreSQL + backend + AI service orchestration

## Run locally

### 1. Database

Install PostgreSQL, create a database named `pawpal`, then run:

```bash
psql "$DATABASE_URL" -f database/schema.sql
psql "$DATABASE_URL" -f database/seed.sql
```

### 2. Backend

```bash
cd backend
npm install
cp .env.example .env
npm run dev
```

Backend default: `http://localhost:4000`

### 3. AI service

```bash
cd ai-service
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

AI service default: `http://localhost:8000`

### 4. Frontend

Serve the `frontend/` directory with any static server. For example:

```bash
cd frontend
python -m http.server 5500
```

Open `http://localhost:5500`.

The included `js/api.js` checks the backend and exposes reusable REST methods. The dashboard still has demo data so it remains usable when the API is offline.

## Docker Compose

```bash
docker compose up --build
```

This starts PostgreSQL, the Node backend and the Python AI service. The database schema/seed are mounted for initialization.

## Important prototype note

Doctor names, qualifications, ratings, prices and sample pet records in the prototype are fictional demonstration data. This project is a software architecture starter, not a veterinary diagnosis system. AI output must be treated as general assistance and reviewed by a qualified veterinarian.
